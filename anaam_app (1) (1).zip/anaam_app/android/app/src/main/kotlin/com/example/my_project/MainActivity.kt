package com.flutterflow.anaamapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
